import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { filter, debounceTime, distinctUntilChanged, switchMap, map, catchError, of } from 'rxjs';
import { Meteo } from 'src/app/core/models/meteo';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-meteo',
  templateUrl: './meteo.component.html',
  styleUrls: ['./meteo.component.css']
})
export class MeteoComponent implements OnInit {
  cityInput: FormControl = new FormControl();
  meteo!: Meteo;

  constructor(private http: HttpClient) { }

  ngOnInit(): void {

    this.cityInput.valueChanges
    .pipe(
      filter((text) => text.length > 2),
      debounceTime(1000),
      distinctUntilChanged(),
      switchMap((text) =>
        this.http.get(
            `http://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&APPID=eb03b1f5e5afb5f4a4edb40c1ef2f534`
          )
          .pipe(
            map((meteo: any) => {
              return {
                temperature: meteo.main.temp,
                humidity: meteo.main.humidity,
                icon:
                  'http://openweathermap.org/img/w/' + meteo.weather[0].icon +'.png',
                error: false,
              };
            }),
            catchError(() => of({ error: true }))
          )
      )
    )
    .subscribe((result) => {
      console.log(result);
      this.meteo = result;
    });

  this.cityInput.setValue("palermo");


  }

}
