import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailSelectorComponent } from './email-selector.component';

describe('EmailSelectorComponent', () => {
  let component: EmailSelectorComponent;
  let fixture: ComponentFixture<EmailSelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmailSelectorComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmailSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
