import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  searchField!: FormControl;
  searches: string[] = [];

  constructor() { }

  ngOnInit(): void {
    this.searchField = new FormControl('',null);

    this.searchField.valueChanges
    .pipe(
      debounceTime(1000),
      distinctUntilChanged()
    )
    .subscribe( term => {
      console.log('-->'+term);
      this.searches.push(term);
    } );

  }

}
