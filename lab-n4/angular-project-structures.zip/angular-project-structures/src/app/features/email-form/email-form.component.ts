import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-form',
  templateUrl: './email-form.component.html',
  styleUrls: ['./email-form.component.css']
})
export class EmailFormComponent implements OnInit {
  public email: string = 'prem@gmail.com';

  constructor() { }

  ngOnInit(): void {
  }

}
