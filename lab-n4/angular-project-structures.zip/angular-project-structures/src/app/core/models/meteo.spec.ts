import { Meteo } from './meteo';

describe('Meteo', () => {
  it('should create an instance', () => {
    expect(new Meteo()).toBeTruthy();
  });
});
