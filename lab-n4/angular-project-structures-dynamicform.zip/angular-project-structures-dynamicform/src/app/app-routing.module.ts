import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DynamicMainFormComponent } from './dynamic-main-form/dynamic-main-form.component';
import { ListRxjsComponent } from './features/rxjs/pages/list/listRxjs.component';
import { AddTutorialComponent } from './features/tutorial/pages/add-tutorial/add-tutorial.component';
import { TutorialDetailsComponent } from './features/tutorial/pages/tutorial-details/tutorial-details.component';
import { TutorialsListComponent } from './features/tutorial/pages/tutorials-list/tutorials-list.component';


const routes: Routes = [
  { path: '', redirectTo: 'tutorials', pathMatch: 'full' },
  { path: 'tutorials', component: TutorialsListComponent },
  { path: 'tutorials/:id', component: TutorialDetailsComponent },
  { path: 'add', component: AddTutorialComponent },
  { path: 'listRxjs', component: ListRxjsComponent },
  { path: 'dynamic', component: DynamicMainFormComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
