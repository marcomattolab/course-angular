import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicMainFormComponent } from './dynamic-main-form.component';

describe('DynamicMainFormComponent', () => {
  let component: DynamicMainFormComponent;
  let fixture: ComponentFixture<DynamicMainFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicMainFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DynamicMainFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
