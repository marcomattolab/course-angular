import { Component, ViewContainerRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../core/models/field-config.interface';
import { Field } from '../core/models/field.interface';



@Component({
  selector: 'app-form-input',
  templateUrl: './form-input.component.html',
  styleUrls: ['./form-input.component.css']
})
export class FormInputComponent implements Field {
  config!: FieldConfig;
  group!: FormGroup;
}
