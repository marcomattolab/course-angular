import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddTutorialComponent } from './features/tutorial/pages/add-tutorial/add-tutorial.component';
import { TutorialDetailsComponent } from './features/tutorial/pages/tutorial-details/tutorial-details.component';
import { TutorialsListComponent } from './features/tutorial/pages/tutorials-list/tutorials-list.component';
import { ListRxjsComponent } from './features/rxjs/pages/list/listRxjs.component';
import { AlfaComponent } from './features/rxjs/pages/alfa/alfa.component';
import { BetaComponent } from './features/rxjs/pages/beta/beta.component';
import { DynamicFieldDirective } from './dynamic-field.directive';
import { FormInputComponent } from './form-input/form-input.component';
import { FormSelectComponent } from './form-select/form-select.component';
import { FormButtonComponent } from './form-button/form-button.component';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { DynamicMainFormComponent } from './dynamic-main-form/dynamic-main-form.component';


@NgModule({
    declarations: [
        AppComponent,
        AddTutorialComponent,
        TutorialDetailsComponent,
        TutorialsListComponent,
        ListRxjsComponent,
        AlfaComponent,
        BetaComponent,
        DynamicFieldDirective,
        FormInputComponent,
        FormSelectComponent,
        FormButtonComponent,
        DynamicFormComponent,
        DynamicMainFormComponent,
    ],
    providers: [],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule
    ]
})
export class AppModule { }
