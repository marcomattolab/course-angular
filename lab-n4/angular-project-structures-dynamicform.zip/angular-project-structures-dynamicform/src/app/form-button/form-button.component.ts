import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../core/models/field-config.interface';
import { Field } from '../core/models/field.interface';


@Component({
  selector: 'app-form-button',
  templateUrl: './form-button.component.html',
  styleUrls: ['./form-button.component.css']
})
export class FormButtonComponent implements Field {
  config!: FieldConfig;
  group!: FormGroup;
}
