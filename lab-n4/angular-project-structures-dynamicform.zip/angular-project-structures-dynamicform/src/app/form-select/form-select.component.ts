import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../core/models/field-config.interface';
import { Field } from '../core/models/field.interface';


@Component({
  selector: 'app-form-select',
  templateUrl: './form-select.component.html',
  styleUrls: ['./form-select.component.css']
})
export class FormSelectComponent implements Field {
  config!: FieldConfig;
  group!: FormGroup;
}
