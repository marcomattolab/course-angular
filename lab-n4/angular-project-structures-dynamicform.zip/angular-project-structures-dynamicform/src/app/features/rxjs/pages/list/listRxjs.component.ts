import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-rxjs',
  templateUrl: './listRxjs.component.html',
  styleUrls: ['./listRxjs.component.css']
})
export class ListRxjsComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

}
