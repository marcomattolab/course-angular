import { Tutorial } from "src/app/core/models/tutorial";


export const TUTORIAL: Tutorial[] = [
  {id: 1, title: 'Angular' , description: 'Course Angular 15', published: true},
  {id: 1, title: 'Java' , description: 'Course Java', published: true},
  {id: 1, title: 'Python' , description: 'Course Python ', published: false},
  {id: 1, title: 'HTML' , description: 'Course HTML5', published: true},
  {id: 1, title: 'C++' , description: 'Course C++', published: true},
  {id: 1, title: 'Pascal' , description: 'Course Pascal ', published: false}
]
