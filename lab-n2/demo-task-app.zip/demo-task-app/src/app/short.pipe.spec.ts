import { ShortPipe } from './short.pipe';

describe('ShortPipe', () => {
  it('create an instance', () => {
    const pipe = new ShortPipe();
    expect(pipe).toBeTruthy();
  });
});
