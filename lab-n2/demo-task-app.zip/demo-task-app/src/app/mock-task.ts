import { Task } from "./task";

export const TASKS: Task[] = [
  {id: 1, name: 'Task 1', description: 'This is a description a', priority: 'low'},
  {id: 2, name: 'Task 2', description: 'This is a description s', priority: 'low'},
  {id: 3, name: 'Task 3', description: 'This is a description', priority: 'medium'},
  {id: 4, name: 'Task 4', description: 'This is a description', priority: 'hight'}


]
