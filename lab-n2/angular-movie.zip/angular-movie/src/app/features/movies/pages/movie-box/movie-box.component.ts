import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MovieModel } from '../../models/movie.model';

@Component({
  selector: 'app-movie-box',
  templateUrl: './movie-box.component.html',
  styleUrls: ['./movie-box.component.scss']
})
export class MovieBoxComponent implements OnInit {
  @Input() movie?: MovieModel;
  @Output() deleteRequest = new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
  }

  deleteMovie() {
    console.debug('Child says: emiting item deleteMovie ', this.movie.title);
    this.deleteRequest.emit(this.movie.title);
  }

}
