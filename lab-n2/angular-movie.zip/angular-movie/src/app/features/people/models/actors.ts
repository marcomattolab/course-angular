export class Actors {

  public adult: boolean;
  public also_known_as: Array<any>;
  public biography: string;
  public birthday: string;
  public deathday: string;
  public gender: number;
  public homepage: string;
  public id: number;
  public imdb_id: string;
  public name: string;
  public place_of_birth: string;
  public popularity: number;
  public profile_path: string;

}
