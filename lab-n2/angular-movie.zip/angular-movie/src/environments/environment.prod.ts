export const environment = {
  production: true,
  theMovieDBApi: '<add-api-key>'
};
