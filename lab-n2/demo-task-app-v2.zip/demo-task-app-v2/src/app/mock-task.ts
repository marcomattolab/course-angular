import { Task } from "./task";

export const TASKS: Task[] = [
  {id: 1, name: 'Task 1' },
  {id: 2, name: 'Task 2' },
  {id: 3, name: 'Task 3' },
  {id: 4, name: 'Task 4' }

]
