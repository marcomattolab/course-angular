import { Directive, Input, OnDestroy, TemplateRef, ViewContainerRef } from '@angular/core';
import { Subject } from 'rxjs';

/**
 * @whatItDoes Conditionally includes an HTML element if current user has any of the authorities passed as the `expression`.
 *
 * @howToUse
 * ```
 *     <some-element *myHasAnyAuthority="'ROLE_ADMIN'">...</some-element>
 *
 *     <some-element *myHasAnyAuthority="['ROLE_ADMIN', 'ROLE_USER']">...</some-element>
 * ```
 */
@Directive({
  selector: '[myHasAnyAuthority]'
})
export class DirettivaDemoDirective implements OnDestroy {
  private authorities!: string | string[];
  private readonly destroy$ = new Subject<void>();

  constructor(private templateRef: TemplateRef<any>, private viewContainerRef: ViewContainerRef) {}


  @Input()
  set myHasAnyAuthority(value: string | string[]) {
    this.authorities = value;
    this.updateView();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private updateView(): void {
    const hasAnyAuthority = this.hasAnyAuthorityService(this.authorities);
    this.viewContainerRef.clear();
    if (hasAnyAuthority) {
      this.viewContainerRef.createEmbeddedView(this.templateRef);
    }
  }

  /**
   * This snippet is located in a Service for Autentication stuff.
   * In particular it uses => "user.realm_access.roles" which is an array of roles related to the logged user.
   */
  private hasAnyAuthorityService(authorities: string[] | string): boolean {
    //Real Service
    //return this.user.realm_access.roles.some((authority: string) => authorities.includes(authority));

    //Mocked Service (ex 1)
    //const roles = ['ROLE_ADMIN']; //Retrieved in the realm of the logged user.
    //Mocked Service (ex 2)
    const roles = ['ROLE_MANAGER']; //Retrieved in the realm of the logged user. (Mock2)
    //Mocked Service (ex 3)
    //const roles = ['ROLE_USER', 'ROLE_ADMIN', 'ROLE_MANAGER']; //Retrieved in the realm of the logged user. (Mock3)

    return roles.some((authority: string) => authorities.includes(authority));
  }

}
