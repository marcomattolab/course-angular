import { Component, OnInit } from '@angular/core';
import { TASKS } from '../mock-task';
import { Task} from '../task'

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  tasks = TASKS;
  selectedTask?: Task;

  constructor() {
  }

  ngOnInit(): void {
  }

  onSelect(task: Task): void{
    console.log("On select...");
    this.selectedTask = task;
  }

  onDelete(task: Task): void{
    console.log("Deleting Task " + task.id);
  }

}
