import { DirettivaDemoDirective } from './direttiva-demo.directive';

describe('DirettivaDemoDirective', () => {
  it('should create an instance', () => {
    const directive = new DirettivaDemoDirective();
    expect(directive).toBeTruthy();
  });
});
