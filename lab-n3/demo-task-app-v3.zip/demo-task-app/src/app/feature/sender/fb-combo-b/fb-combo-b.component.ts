import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-fb-combo-b',
  templateUrl: './fb-combo-b.component.html',
  styleUrls: ['./fb-combo-b.component.css']
})
export class FbComboBComponent implements OnInit, OnDestroy{
    value: number | undefined;
    subscription: Subscription;

  constructor(public dataService: DataService) {
    this.subscription = dataService.data$.subscribe(val => this.value = val)
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
