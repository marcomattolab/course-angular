import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FbComboBComponent } from './fb-combo-b.component';

describe('FbComboBComponent', () => {
  let component: FbComboBComponent;
  let fixture: ComponentFixture<FbComboBComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FbComboBComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FbComboBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
