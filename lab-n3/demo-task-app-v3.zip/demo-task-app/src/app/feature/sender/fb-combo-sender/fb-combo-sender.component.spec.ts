import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FbComboSenderComponent } from './fb-combo-sender.component';

describe('FbComboSenderComponent', () => {
  let component: FbComboSenderComponent;
  let fixture: ComponentFixture<FbComboSenderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FbComboSenderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FbComboSenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
