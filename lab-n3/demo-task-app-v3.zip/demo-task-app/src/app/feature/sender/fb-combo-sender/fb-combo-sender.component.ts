import { Component, OnInit} from '@angular/core';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-fb-combo-sender',
  templateUrl: './fb-combo-sender.component.html',
  styleUrls: ['./fb-combo-sender.component.css']
})
export class FbComboSenderComponent {
    count = 0;

    constructor(private dataService: DataService) { }

    add(){
        this.dataService.update(++this.count);
    }
}
