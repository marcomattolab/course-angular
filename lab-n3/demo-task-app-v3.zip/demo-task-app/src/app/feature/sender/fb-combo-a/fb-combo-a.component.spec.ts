import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FbComboAComponent } from './fb-combo-a.component';

describe('FbComboAComponent', () => {
  let component: FbComboAComponent;
  let fixture: ComponentFixture<FbComboAComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FbComboAComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FbComboAComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
