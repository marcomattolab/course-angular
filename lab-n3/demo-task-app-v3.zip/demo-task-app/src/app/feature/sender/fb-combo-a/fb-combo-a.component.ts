import { Component } from '@angular/core';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-fb-combo-a',
  templateUrl: './fb-combo-a.component.html',
  styleUrls: ['./fb-combo-a.component.css']
})
export class FbComboAComponent {

    constructor(public dataService: DataService) { }

}
