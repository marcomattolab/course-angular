import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TasksComponent } from './tasks/tasks.component';
import { DirettivaDemoDirective } from './direttiva-demo.directive';
import { FormsModule } from '@angular/forms';
import { ShortPipe } from './short.pipe';
import { FilterPipe } from './filter.pipe';
import { FbComboSenderComponent } from './feature/sender/fb-combo-sender/fb-combo-sender.component';
import { FbComboAComponent } from './feature/sender/fb-combo-a/fb-combo-a.component';
import { FbComboBComponent } from './feature/sender/fb-combo-b/fb-combo-b.component';


@NgModule({
  declarations: [
    AppComponent,
    TasksComponent,
    DirettivaDemoDirective,
    ShortPipe,
    FilterPipe,
    FbComboSenderComponent,
    FbComboAComponent,
    FbComboBComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
