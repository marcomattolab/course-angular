import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddTutorialComponent } from './features/tutorial/pages/add-tutorial/add-tutorial.component';
import { TutorialDetailsComponent } from './features/tutorial/pages/tutorial-details/tutorial-details.component';
import { TutorialsListComponent } from './features/tutorial/pages/tutorials-list/tutorials-list.component';
import { ListRxjsComponent } from './features/rxjs/pages/list/listRxjs.component';
import { AlfaComponent } from './features/rxjs/pages/alfa/alfa.component';
import { BetaComponent } from './features/rxjs/pages/beta/beta.component';


@NgModule({
    declarations: [
        AppComponent,
        AddTutorialComponent,
        TutorialDetailsComponent,
        TutorialsListComponent,
        ListRxjsComponent,
        AlfaComponent,
        BetaComponent
    ],
    providers: [],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpClientModule
    ]
})
export class AppModule { }
